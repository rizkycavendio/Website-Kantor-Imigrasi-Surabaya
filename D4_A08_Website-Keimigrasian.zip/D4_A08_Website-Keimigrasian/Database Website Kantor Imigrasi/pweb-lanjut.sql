-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Waktu pembuatan: 06 Jun 2022 pada 09.41
-- Versi server: 5.7.33
-- Versi PHP: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pweb-lanjut`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `feedback`
--

CREATE TABLE `feedback` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `ulasan` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `ulasan`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dengan adanya sistem online mempermudah kami untuk mengurus paspor', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(2, 3, 'Dengan adanya layanan online mempermudah masyarakat, Terima kasih Imigrasi Surabaya', '2022-06-05 00:56:35', '2022-06-05 00:56:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kewarganegaraans`
--

CREATE TABLE `kewarganegaraans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kewarganegaraan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kewarganegaraans`
--

INSERT INTO `kewarganegaraans` (`id`, `kewarganegaraan`, `created_at`, `updated_at`) VALUES
(1, 'WNI', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(2, 'WNA', '2022-06-05 00:45:42', '2022-06-05 00:45:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_06_03_040322_create_pemohon_paspors_table', 1),
(6, '2022_06_03_144251_create_kewarganegaraans_table', 1),
(7, '2022_06_03_153206_create_pekerjaans_table', 1),
(8, '2022_06_04_131718_create_pembaruan_paspors_table', 1),
(9, '2022_06_05_043126_create_feedback_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pekerjaans`
--

CREATE TABLE `pekerjaans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pekerjaan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pekerjaans`
--

INSERT INTO `pekerjaans` (`id`, `pekerjaan`, `created_at`, `updated_at`) VALUES
(1, 'Pegawai Negeri', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(2, 'Pegawai Swasta', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(3, 'Wiraswasta', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(4, 'Pedagang', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(5, 'Pengajar', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(6, 'Pelajar/Mahasiswa', '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(7, 'Lainnya', '2022-06-05 00:45:42', '2022-06-05 00:45:42');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembaruan_paspors`
--

CREATE TABLE `pembaruan_paspors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `kewarganegaraan_id` bigint(20) UNSIGNED NOT NULL,
  `pekerjaan_id` bigint(20) UNSIGNED NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_ktp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_paspor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_paspor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tggl_pembaruan` date NOT NULL,
  `alasan` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemohon_paspors`
--

CREATE TABLE `pemohon_paspors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `kewarganegaraan_id` bigint(20) UNSIGNED NOT NULL,
  `pekerjaan_id` bigint(20) UNSIGNED NOT NULL,
  `img_kk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_ktp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img_akte` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempat_lahir` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tggl_lahir` date NOT NULL,
  `tggl_pengajuan` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pemohon_paspors`
--

INSERT INTO `pemohon_paspors` (`id`, `user_id`, `kewarganegaraan_id`, `pekerjaan_id`, `img_kk`, `img_ktp`, `img_akte`, `nama`, `tempat_lahir`, `tggl_lahir`, `tggl_pengajuan`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 6, 'img-pemohon-kk/UxZKuqs2gBrKidpubMY7j69LEA62ZArb6bKyhXkv.jpg', 'img-pemohon-ktp/GaXffFUiuAwLmHHxAAoASw2FyMLhJUKidJaoDjPz.png', 'img-pemohon-akte/EfgpN2CeNruz174NWWH53KtAaZSdfYdFtDaeb6sY.jpg', 'Figo Gymnastiar Farhaan Pratama', 'Surabaya', '2001-07-18', '2022-06-05', '2022-06-05 00:54:54', '2022-06-05 00:55:50'),
(2, 1, 1, 5, 'img-pemohon-kk/euOKbkIiTR4rK0z7Phmz0QJCHORnMdKeJ0Yvsc27.png', 'img-pemohon-ktp/v8yLoP5TpiAdYaY4XkY54PBJajXAmIpLjh2taDN3.jpg', 'img-pemohon-akte/Ezsxxxq1o8eOINL1wmFEDlGIwQq7Q8gI3yMvXZL0.jpg', 'Muhammad Rizky Cavendio', 'Jakarta', '2022-06-06', '2022-06-06', '2022-06-05 22:38:40', '2022-06-05 22:38:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `kewarganegaraan_id` bigint(20) UNSIGNED NOT NULL,
  `pekerjaan_id` bigint(20) UNSIGNED NOT NULL,
  `nik` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_telp` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_kelamin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `kewarganegaraan_id`, `pekerjaan_id`, `nik`, `nama`, `no_telp`, `email`, `email_verified_at`, `password`, `jenis_kelamin`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 6, '20051397011', 'Muhammad Rizky Cavendio', '081281058588', 'mrc.dio2001@gmail.com', NULL, '$2y$10$da615W7yam3t.UTLcxWZuOL864tiNkNSNeAhQWPNd/PHEyS1bGkM.', 'Laki-laki', NULL, '2022-06-05 00:45:42', '2022-06-05 00:45:42'),
(3, 1, 6, '20051397015', 'Figo Gymnastiar Farhaan Pratama', '081276584566', 'figo@gmail.com', NULL, '$2y$10$r91DgDElM59b47PLVaJ3tOpjT0.plbmeUdIFE1H5LCGgq2.pUHvJ6', 'Laki-laki', NULL, '2022-06-05 00:53:48', '2022-06-05 00:53:48');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kewarganegaraans`
--
ALTER TABLE `kewarganegaraans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `pekerjaans`
--
ALTER TABLE `pekerjaans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembaruan_paspors`
--
ALTER TABLE `pembaruan_paspors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pembaruan_paspors_no_paspor_unique` (`no_paspor`);

--
-- Indeks untuk tabel `pemohon_paspors`
--
ALTER TABLE `pemohon_paspors`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_nik_unique` (`nik`),
  ADD UNIQUE KEY `users_no_telp_unique` (`no_telp`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `kewarganegaraans`
--
ALTER TABLE `kewarganegaraans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `pekerjaans`
--
ALTER TABLE `pekerjaans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `pembaruan_paspors`
--
ALTER TABLE `pembaruan_paspors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `pemohon_paspors`
--
ALTER TABLE `pemohon_paspors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
