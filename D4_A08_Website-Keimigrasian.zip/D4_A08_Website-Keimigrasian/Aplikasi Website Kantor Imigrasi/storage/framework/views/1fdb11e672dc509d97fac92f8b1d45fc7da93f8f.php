

<?php $__env->startSection('container'); ?>
<section class="mt-3">
    <div class="container">
        <div class="text-center mt-5 mb-5">
            <h2>Berita</h2>
            <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
            <p class="lead text-muted">Berita seputar keimigrasian Surabaya</p>
        </div>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita1.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 1</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita2.jpeg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 2</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita3.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 3</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita4.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 4</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita5.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 5</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
            <div class="col">
              <div class="card h-100">
                <img src="/img/berita6.jpg" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">Berita 6</h5>
                  <p class="card-text">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Numquam natus consequatur nihil iure, omnis beatae mollitia totam similique odio fuga dolore minus in perferendis temporibus quisquam id. Nesciunt voluptas corporis ea earum veniam, sapiente ad maxime suscipit commodi perspiciatis accusantium consequuntur incidunt error ducimus saepe magni autem. Necessitatibus, temporibus non.</p>
                </div>
                <div class="card-footer">
                  <small class="text-muted">Last updated 3 mins ago</small>
                </div>
              </div>
            </div>
          </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

 
      


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/berita/index.blade.php ENDPATH**/ ?>