

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-3 mb-5">
  <h2>Edit Data Pembaruan Paspor</h2>
    <hr>
  <div class="row">
      <div class="col-lg-8">
          <main class="form-signin w-100 m-auto">
            <?php if(session()->has('loginError')): ?>
              
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              
                <?php echo e(session('loginError')); ?>   
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
            <?php endif; ?>
            <form action="/dashboard/pembaruan/<?php echo e($pembaruan->id); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>
              <div class="container">
                  <div class="mb-2">
                    <label for="nama" class="from-label">Nama:</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" placeholder="Masukkan nama Anda..." name="nama" autofocus value="<?php echo e(old('nama', $pembaruan->nama)); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      <?php $__currentLoopData = $pekerjaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pekerjaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('pekerjaan_id', $pembaruan->pekerjaan_id) == $pekerjaan->id): ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"selected><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php else: ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Kewarganegaraan:</label>
                    <select class="form-select" name="kewarganegaraan_id" >
                      <?php $__currentLoopData = $kewarganegaraans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kewarganegaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('kewarganegaraan_id', $pembaruan->kewarganegaraan_id) == $kewarganegaraan->id): ?>
                        <option value="<?php echo e($kewarganegaraan->id); ?>"selected><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                        <?php else: ?>
                        <option value="<?php echo e($kewarganegaraan->id); ?>"><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                 <div class="mb-3">
                  <label for="img_ktp" class="form-label">Upload Kartu Identitas (KTP/Kartu Pelajar/SIM)</label>
                  <?php if($pembaruan->img_ktp): ?>
                    <img src="<?php echo e(asset('storage/'.$pembaruan->img_ktp)); ?>" class="img-preview2 img-fluid mb-3 col-sm-5 d-block">
                    <?php endif; ?>
                  <input class="form-control  <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="img_ktp" name="img_ktp" onchange="previewImg_ktp()">
                    <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                          <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="mb-2">
                    <label for="no_paspor" class="from-label">No Paspor:</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['no_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_paspor" placeholder="Masukkan nomer paspor Anda..." name="no_paspor" autofocus value="<?php echo e(old('no_paspor', $pembaruan->no_paspor)); ?>">
                    <?php $__errorArgs = ['no_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                 <div class="mb-3">
                  <label for="img_paspor" class="form-label">Upload Paspor Lama</label>
                  <?php if($pembaruan->img_paspor): ?>
                    <img src="<?php echo e(asset('storage/'.$pembaruan->img_paspor)); ?>" class="img-preview4 img-fluid mb-3 col-sm-5 d-block">
                  <?php endif; ?>
                  <input class="form-control  <?php $__errorArgs = ['img_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="img_paspor" name="img_paspor" onchange="previewImg_paspor()">
                    <?php $__errorArgs = ['img_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                          <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                 <div class="mb-2">
                    <label for="alasan" class="from-label">Alasan Pembaruan:</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="alasan" placeholder="Masukkan alasan Anda..." name="alasan" value="<?php echo e(old('alasan', $pembaruan->alasan)); ?>">
                    <?php $__errorArgs = ['alasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-2">
                  <label for="tggl_pembaruan" class="from-label">Tanggal Pembaruan Paspor:</label>
                  <input type="date" class="form-control <?php $__errorArgs = ['tggl_pembaruan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tggl_pembaruan" placeholder="name@example.com" name="tggl_pembaruan" value="<?php echo e(old('tggl_pembaruan', $pembaruan->tggl_pembaruan)); ?>">
                  <?php $__errorArgs = ['tggl_pembaruan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <button class="btn btn-lg btn-success mt-3" type="submit">Perbaharui Data</button>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/pembaruan/edit.blade.php ENDPATH**/ ?>