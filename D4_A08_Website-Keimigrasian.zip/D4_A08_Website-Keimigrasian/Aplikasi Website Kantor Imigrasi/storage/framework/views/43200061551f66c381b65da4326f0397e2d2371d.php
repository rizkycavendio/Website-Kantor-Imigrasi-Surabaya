

<?php $__env->startSection('container'); ?>
<section class="mt-3">
   <div class="container-lg">
          <div class="text-center mt-3">
              <h2>Visi & Misi</h2>
              <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
              <p class="lead text-muted">Visi dan Misi Kantor Imigrasi Surabaya</p>
          </div>
          <div class="row mt-5 justify-content-center">
            <div class="col-lg-8">
                <h2>VISI:</h2>
                <p class="text-muted">"Masyarakat Memperoleh Kepastian Pelayanan dan Penegakan Hukum Keimigrasian"</p>

                <h2>MISI:</h2>
                <p class="text-muted text-right">
                  1. Memperkuat penegakan hukum keimigrasian yang adil dan akuntabel. <br>
                  2. Mendukung terciptanya keamanan negara yang stabil. <br>
                  3. Meningkatkan pelayanan keimigrasian yang prima. <br>
                  4. Mendukung pembangunan kesejahteraan masayarakat yang berkesinambungan.</p>

                <h2>MOTTO: </h2>  
                <P class="text-muted">"NYALI WANI (Nyata Peduli Wajib Melayani)"</P>

                <h2>JANJI LAYANAN:</h2>
                <p class="text-muted text-right">
                  1. Kepastian Persyaratan <br>
                  2. Kepastian Biaya <br>
                  3. Kepastian Waktu Penyelesaian <br>
            </div>
          </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

 
      


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/visimisi/index.blade.php ENDPATH**/ ?>