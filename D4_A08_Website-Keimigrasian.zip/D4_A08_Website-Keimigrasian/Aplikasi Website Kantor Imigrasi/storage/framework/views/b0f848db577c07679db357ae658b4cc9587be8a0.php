

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <main class="form-signin w-100 m-auto">
              <?php if(session()->has('loginError')): ?>
                
               <div class="alert alert-danger alert-dismissible fade show" role="alert">
                
                  <?php echo e(session('loginError')); ?>   
                  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
               </div>
              <?php endif; ?>
              <form action="/register" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card shadow border-0 p-5 mb-5">
                  <h1 class="h3 mb-3 fw-normal text-center">Registrasi</h1>
                  <div class="mb-3">
                  <label for="nik" class="from-label">NIK: </label>
                  <input type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nik" placeholder="200513...." name="nik" value="<?php echo e(old('nik')); ?>" autofocus>
                    <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-3">
                    <label for="nama" class="from-label">Nama: </label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" placeholder="Nama Anda...." name="nama" value="<?php echo e(old('nama')); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-3">
                    <label for="no_telp" class="from-label">No. Telp</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="no_telp" placeholder="0812....." name="no_telp" value="<?php echo e(old('no_telp')); ?>">
                    <?php $__errorArgs = ['no_telp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-3">
                    <label for="jenis_kelamin" class="from-label">Jenis Kelamin</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="jenis_kelamin" placeholder="Laki-laki/Perempuan" name="jenis_kelamin" value="<?php echo e(old('jenis_kelamin')); ?>">
                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-3">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      <?php $__currentLoopData = $pekerjaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pekerjaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('pekerjaan_id') == $pekerjaan->id): ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"selected><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php else: ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                 <div class="mb-3">
                  <label for="slug" class="form-label">Kewarganegaraan:</label>
                  <select class="form-select" name="kewarganegaraan_id" >
                    <?php $__currentLoopData = $kewarganegaraans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kewarganegaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(old('kewarganegaraan_id') == $kewarganegaraan->id): ?>
                      <option value="<?php echo e($kewarganegaraan->id); ?>"selected><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                      <?php else: ?>
                      <option value="<?php echo e($kewarganegaraan->id); ?>"><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
                <div class="mb-3">
                  <label for="email" class="from-label">Email address</label>
                  <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="name@gmail.com" name="email" value="<?php echo e(old('email')); ?>">
                  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-3">
                  <label for="password" class="from-label">Password</label>
                  <input type="password" class="form-control" id="password" placeholder="Password" name="password">
                </div>
                <button class="w-100 btn btn-lg btn-warning mt-5" type="submit">Registrasi</button>
                <small class="d-block text-center mt-2">Sudah punya akun? <a href="/login"> Login di sini</a></small>
                </div>
              </form>
            </main>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/register/index.blade.php ENDPATH**/ ?>