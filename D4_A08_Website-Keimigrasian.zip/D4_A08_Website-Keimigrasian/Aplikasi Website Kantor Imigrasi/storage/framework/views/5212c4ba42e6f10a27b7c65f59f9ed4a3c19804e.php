

<?php $__env->startSection('container'); ?>
<section class="mt-3">
   <div class="container-lg">
          <div class="text-center mt-3">
              <h2>Tugas & Fungsi</h2>
              <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
              <p class="lead text-muted">Tugas dan Fungsi Kantor Imigrasi Surabaya</p>
          </div>
          <div class="row mt-5 justify-content-center">
            <div class="col-lg-8 text-center">
                <h2>TUGAS:</h2>
                <p class="text-muted">Melaksanakan sebagian tugas pokok dan fungsi Kementerian Hukum dan HAM di Bidang Keimigrasian di wilayah kerjanya.</p>

                <h2>FUNGSI:</h2>
                <p class="text-muted text-right">
                    Untuk menyelenggarakan tugas tersebut Kantor Imigrasi mempunyai fungsi : <br> <br>
                  1. Melaksanakan tugas di bidang Tata Usaha. <br>
                  2. Melaksanakan tugas Keimigrasian di bidang Lalu Lintas dan Status Keimigrasian.<br>
                  3. Melaksanakan tugas Keimigrasian di bidang Pengawasan dan Penindakan Keimigrasian.<br>
                  4. Melaksanakan tugas Keimigrasian di bidang Informasi dan Sarana Komunikasi Keimigrasian. <br>
                  5. Melaksanakan tugas Keimigrasian di bidang Pendaratan dan Izin Masuk Keimigrasian.</p>
            </div>
          </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

 
      


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/tugasfungsi/index.blade.php ENDPATH**/ ?>