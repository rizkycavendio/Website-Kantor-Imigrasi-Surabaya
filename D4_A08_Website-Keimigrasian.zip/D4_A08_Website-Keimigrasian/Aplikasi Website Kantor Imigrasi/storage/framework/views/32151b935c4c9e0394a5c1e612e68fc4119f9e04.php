

<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Data Pengajuan Paspor Anda</h1>
  </div>

  <div class="table-responsive col-lg-12">
    <a href="/dashboard/pemohon" class="btn btn-info mb-2">Kembali <--- </a>
    <table class="table table-info table-striped-columns table-bordered border-dark table-sm">
      <thead>
        <tr>
          <th scope="col">No. Antrian</th>
          <th scope="col">Nama</th>
          <th scope="col">NIK</th>
          <th scope="col">Tempat Lahir</th>
          <th scope="col">Tanggal Lahir</th>
          <th scope="col">Pekerjaan</th>
          <th scope="col">Kewarganegaraan</th>
          <th scope="col">File KK</th>
          <th scope="col">File Identitas (KTP/SIM/Lainnya)</th>
          <th scope="col">File Akte</th>
          <th scope="col">Tanggal Pengajuan</th>
        </tr>
      </thead>
      <tbody>
       <tr>
         <td><?php echo e($pemohon->id); ?></td>
         <td><?php echo e($pemohon->nama); ?></td>
         <td><?php echo e($pemohon->user->nik); ?></td>
         <td><?php echo e($pemohon->tempat_lahir); ?></td>
         <td><?php echo e($pemohon->tggl_lahir); ?></td>
         <td><?php echo e($pemohon->pekerjaan->pekerjaan); ?></td>
         <td><?php echo e($pemohon->kewarganegaraan->kewarganegaraan); ?></td>
         <td><img src="<?php echo e(asset('storage/'.$pemohon->img_kk)); ?>" class="img-preview1 img-fluid" style="max-width: 100px"></td>
         <td><img src="<?php echo e(asset('storage/'.$pemohon->img_ktp)); ?>" class="img-preview2 img-fluid" style="max-width: 100px"></td>
         <td><img src="<?php echo e(asset('storage/'.$pemohon->img_akte)); ?>" class="img-preview3 img-fluid" style="max-width: 100px"></td>
         <td><?php echo e($pemohon->tggl_pengajuan); ?></td>
       </tr>
      </tbody>
    </table>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/pemohon/show.blade.php ENDPATH**/ ?>