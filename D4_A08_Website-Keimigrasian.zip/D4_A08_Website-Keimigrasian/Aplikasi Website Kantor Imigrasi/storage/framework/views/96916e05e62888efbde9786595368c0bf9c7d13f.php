
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="/img/slider1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="/img/slider3.jpeg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="/img/slider4.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<nav class="navbar sticky-top navbar-expand-lg" style="background-color: #ffffff;">
    <div class="container-lg">
      <a class="navbar-brand text-dark" href="#">
        <img src="/img/logo_im.png" alt="" width="40" height="35" class="d-inline-block">
        Kantor Imigrasi Surabaya
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('/') ? 'active' : ''); ?>" aria-current="page" href="/">Beranda</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo e(Request::is('profil*') ? 'active' : ''); ?>" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Profil
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="/profil/visimisi">Visi & Misi</a></li>
              <li><a class="dropdown-item" href="/profil/sejarah">Sejarah</a></li>
              <li><a class="dropdown-item" href="/profil/tugasfungsi">Tugas & Fungsi</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle <?php echo e(Request::is('dashboard*') ? 'active' : ''); ?>" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Pelayanan
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <li><a class="dropdown-item" href="/dashboard/pemohon">Pengajuan Paspor</a></li>
              <li><a class="dropdown-item" href="/dashboard/pembaruan">Pembaruan Paspor</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('pelayanan/feedback') ? 'active' : ''); ?>" href="/pelayanan/feedback">Indeks Kepuasan Masyarakat</a>
          </li>
          <li class="nav-item">
            <a class="nav-link <?php echo e(Request::is('pelayanan/berita') ? 'active' : ''); ?>" href="/pelayanan/berita">Berita</a>
          </li>
          <?php if(auth()->guard()->check()): ?>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Halo, <?php echo e(auth()->user()->nama); ?> 
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="/dashboard"><i class="bi bi-layout-text-sidebar-reverse"></i> My Dashboard</a></li>
              <li><hr class="dropdown-divider"></li>
              <li>
                <form action="/logout" method="POST">
                  <?php echo csrf_field(); ?>
                  <button type="submit" class="dropdown-item"><i class="bi bi-box-arrow-in-right"></i> Log out</button>
                </form>
              </li>
            </ul>
          </li>
          <?php else: ?>
          <li class="nav-item">
            <div class="spinner-grow spinner-grow-sm text-success position-absolute" role="status">
              <span class="visually-hidden" style="">Loading...</span>
            </div>
            <a class="nav-link btn btn-warning text-light" href="/login">Login</a>
          </li>
          <?php endif; ?>
        </ul>
    </div>
  </nav><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/partials/nav.blade.php ENDPATH**/ ?>