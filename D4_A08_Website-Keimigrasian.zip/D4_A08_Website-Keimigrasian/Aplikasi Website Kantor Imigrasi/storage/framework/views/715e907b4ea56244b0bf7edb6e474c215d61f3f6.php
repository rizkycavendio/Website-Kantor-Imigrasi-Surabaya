

<?php $__env->startSection('container'); ?>
<div class="container-lg mt-3 mb-5">
  <h2>Edit Data Pengajuan Paspor</h2>
    <hr>
  <div class="row">
      <div class="col-lg-8">
          <main class="form-signin w-100 m-auto">
            <?php if(session()->has('loginError')): ?>
              
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              
                <?php echo e(session('loginError')); ?>   
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
            <?php endif; ?>
            <form action="/dashboard/pemohon/<?php echo e($pemohon->id); ?>" method="POST" enctype="multipart/form-data">
              <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>
              <div class="container">
                  <div class="mb-2">
                    <label for="nama" class="from-label">Nama</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama" placeholder="Masukkan nama Anda..." name="nama" autofocus value="<?php echo e(old('nama', $pemohon->nama)); ?>">
                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-2">
                    <label for="tempat_lahir" class="from-label">Tempat Lahir</label>
                    <input type="text" class="form-control <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tempat_lahir" placeholder="Masukkan tempat lahir Anda..." name="tempat_lahir" value="<?php echo e(old('tempat_lahir', $pemohon->tempat_lahir)); ?>">
                    <?php $__errorArgs = ['tempat_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-2">
                    <label for="tggl_lahir" class="from-label">Tanggal Lahir</label>
                    <input type="date" class="form-control <?php $__errorArgs = ['tggl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tggl_lahir" placeholder="Masukkan tanggal lahir Anda..." name="tggl_lahir" value="<?php echo e(old('tggl_lahir', $pemohon->tggl_lahir)); ?>">
                    <?php $__errorArgs = ['tggl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      <?php $__currentLoopData = $pekerjaans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pekerjaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(old('pekerjaan_id', $pemohon->pekerjaan_id) == $pekerjaan->id): ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"selected><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php else: ?>
                        <option value="<?php echo e($pekerjaan->id); ?>"><?php echo e($pekerjaan->pekerjaan); ?></option>  
                        <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                 </div>
                 <div class="mb-2">
                  <label for="slug" class="form-label">Kewarganegaraan:</label>
                  <select class="form-select" name="kewarganegaraan_id" >
                    <?php $__currentLoopData = $kewarganegaraans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kewarganegaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(old('kewarganegaraan_id', $pemohon->kewarganegaraan_id) == $kewarganegaraan->id): ?>
                      <option value="<?php echo e($kewarganegaraan->id); ?>"selected><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                      <?php else: ?>
                      <option value="<?php echo e($kewarganegaraan->id); ?>"><?php echo e($kewarganegaraan->kewarganegaraan); ?></option>  
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  </div>
                  <div class="mb-3">
                    <label for="img_kk" class="form-label">Kartu Keluarga (KK)</label>
                    <?php if($pemohon->img_kk): ?>
                    <img src="<?php echo e(asset('storage/'.$pemohon->img_kk)); ?>" class="img-preview1 img-fluid mb-3 col-sm-5 d-block">
                    <?php endif; ?>
                    <input class="form-control  <?php $__errorArgs = ['img_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="img_kk" name="img_kk" onchange="previewImg_kk()">
                      <?php $__errorArgs = ['img_kk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                            <?php echo e($message); ?>

                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
                   <div class="mb-3">
                    <label for="img_ktp" class="form-label">Kartu Identitas (KTP/Kartu Pelajar/SIM)</label>
                    <?php if($pemohon->img_ktp): ?>
                    <img src="<?php echo e(asset('storage/'.$pemohon->img_ktp)); ?>" class="img-preview2 img-fluid mb-3 col-sm-5 d-block">
                    <?php endif; ?>
                    <input class="form-control  <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="img_ktp" name="img_ktp" onchange="previewImg_ktp()">
                      <?php $__errorArgs = ['img_ktp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                            <?php echo e($message); ?>

                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
                   <div class="mb-3">
                    <label for="img_akte" class="form-label">Akte Kelahiran</label>
                    <?php if($pemohon->img_akte): ?>
                    <img src="<?php echo e(asset('storage/'.$pemohon->img_akte)); ?>" class="img-preview3 img-fluid mb-3 col-sm-5 d-block">
                    <?php endif; ?>
                    <input class="form-control  <?php $__errorArgs = ['img_akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="img_akte" name="img_akte" onchange="previewImg_akte()">
                      <?php $__errorArgs = ['img_akte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="invalid-feedback">
                            <?php echo e($message); ?>

                          </div>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </div>
                  <div class="mb-2">
                  <label for="tggl_pengajuan" class="from-label">Tanggal Pengajuan Paspor</label>
                  <input type="date" class="form-control <?php $__errorArgs = ['tggl_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tggl_pengajuan" placeholder="name@example.com" name="tggl_pengajuan" value="<?php echo e(old('tggl_pengajuan', $pemohon->tggl_pengajuan)); ?>">
                  <?php $__errorArgs = ['tggl_pengajuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <button class="btn btn-lg btn-success mt-5" type="submit">Perbaharui Data</button>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('dashboardUser/layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pweb-lanjut\resources\views/dashboardUser/pemohon/edit.blade.php ENDPATH**/ ?>