<?php

use App\Http\Controllers\BeritaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\DashboardPemohonController;
use App\Http\Controllers\DashboardPembaruanController;
use App\Http\Controllers\DashboardFeedbackController;
use App\Http\Controllers\SejarahController;
use App\Http\Controllers\TugasFungsiController;
use App\Http\Controllers\VisiMisiController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home', [
        'title' => 'Beranda'
    ]);
});

Route::get('/login', [LoginController::class, 'index'])->name('login')->middleware('guest');
Route::post('/login', [LoginController::class, 'authenticate']);
Route::post('/logout', [LoginController::class, 'logout']);

Route::get('/register', [RegisterController::class, 'index'])->middleware('guest');
Route::post('/register', [RegisterController::class, 'store']);

Route::get('/dashboard', function () {
    return view('dashboardUser/dashboard');
})->middleware('auth');

Route::get('/pelayanan/feedback', [FeedbackController::class, 'index']);

Route::get('/pelayanan/berita', [BeritaController::class, 'index']);

Route::get('/profil/visimisi', [VisiMisiController::class, 'index']);

Route::get('/profil/sejarah', [SejarahController::class, 'index']);

Route::get('/profil/tugasfungsi', [TugasFungsiController::class, 'index']);

Route::resource('/dashboard/pemohon', DashboardPemohonController::class)->middleware('auth');

Route::resource('/dashboard/pembaruan', DashboardPembaruanController::class)->middleware('auth');

Route::resource('/dashboard/feedback', DashboardFeedbackController::class)->middleware('auth');
