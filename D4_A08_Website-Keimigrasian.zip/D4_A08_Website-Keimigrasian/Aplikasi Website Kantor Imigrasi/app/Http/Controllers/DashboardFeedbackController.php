<?php

namespace App\Http\Controllers;

use App\Models\Feedback;
use Illuminate\Http\Request;

class DashboardFeedbackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboardUser/feedback/index', [
            'feedbacks' => Feedback::where('user_id', auth()->user()->id)->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboardUser/feedback/create', [
            'feedbacks' => Feedback::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'ulasan' => 'required|max:255'
        ]);

        $validateData['user_id'] = auth()->user()->id;
        Feedback::create($validateData);

        return redirect('dashboard/feedback')->with('success', 'Ulasan Anda berhasil terkirim!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Feedback  $feedback
     * @return \Illuminate\Http\Response
     */
    public function show(Feedback $feedback)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Feedback  $feedback
     * @return \Illuminate\Http\Response
     */
    public function edit(Feedback $feedback)
    {
        return view('dashboardUser/feedback/edit', [
            'feedback' => $feedback
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Feedback  $feedback
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Feedback $feedback)
    {
        $validateData = $request->validate([
            'ulasan' => 'required|max:255'
        ]);

        $validateData['user_id'] = auth()->user()->id;

        Feedback::where('id', $feedback->id)
            ->update($validateData);

        return redirect('dashboard/feedback')->with('success', 'Ulasan Anda berhasil diUPDATE!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Feedback  $feedback
     * @return \Illuminate\Http\Response
     */
    public function destroy(Feedback $feedback)
    {
        Feedback::destroy($feedback->id);

        return redirect('dashboard/feedback')->with('success', 'Ulasan berhasil dihapus!');
    }
}
