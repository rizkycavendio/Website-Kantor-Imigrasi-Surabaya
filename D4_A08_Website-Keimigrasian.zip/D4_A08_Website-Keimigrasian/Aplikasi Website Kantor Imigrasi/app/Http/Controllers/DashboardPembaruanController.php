<?php

namespace App\Http\Controllers;

use App\Models\Pekerjaan;
use Illuminate\Http\Request;
use App\Models\Kewarganegaraan;
use App\Models\PembaruanPaspor;
use Illuminate\Support\Facades\Storage;

class DashboardPembaruanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboardUser/pembaruan/index', [
            'pembaruans' => PembaruanPaspor::where('user_id', auth()->user()->id)->get()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboardUser/pembaruan/create', [
            'kewarganegaraans' => Kewarganegaraan::all(),
            'pekerjaans' => Pekerjaan::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'nama' => 'required|max:255',
            'no_paspor' => 'required|max:7|min:7|unique:pembaruan_paspors',
            'img_paspor' => 'required|file|max:1024',
            'kewarganegaraan_id' => 'required',
            'pekerjaan_id' => 'required',
            'img_ktp' => 'required|file|max:1024',
            'tggl_pembaruan' => 'required|date',
            'alasan' => 'required|max:255'
        ]);

        if ($request->file('img_paspor')) {
            $validateData['img_paspor'] = $request->file('img_paspor')->store('img-pembaruan-paspor');
        }

        if ($request->file('img_ktp')) {
            $validateData['img_ktp'] = $request->file('img_ktp')->store('img-pembaruan-ktp');
        }

        $validateData['user_id'] = auth()->user()->id;
        PembaruanPaspor::create($validateData);

        return redirect('/dashboard/pembaruan')->with('success', 'Pembaruan paspor Anda BERHASIL!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function show(PembaruanPaspor $pembaruan)
    {
        return view('dashboardUser/pembaruan/show', [
            'pembaruan' => $pembaruan,
            'kewarganegaraans' => Kewarganegaraan::all(),
            'pekerjaans' => Pekerjaan::all()
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function edit(PembaruanPaspor $pembaruan)
    {
        return view('dashboardUser/pembaruan/edit', [
            'pembaruan' => $pembaruan,
            'pekerjaans' => Pekerjaan::all(),
            'kewarganegaraans' => Kewarganegaraan::all()
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PembaruanPaspor $pembaruan)
    {
        $rules = [
            'nama' => 'required|max:255',
            'no_paspor' => 'required|max:7|min:7|unique:pembaruan_paspors',
            'img_paspor' => 'required|file|max:1024',
            'kewarganegaraan_id' => 'required',
            'pekerjaan_id' => 'required',
            'img_ktp' => 'required|file|max:1024',
            'tggl_pembaruan' => 'required|date',
            'alasan' => 'required|max:255'
        ];

        $validateData = $request->validate($rules);

        if ($request->file('img_ktp')) {
            if ($pembaruan->img_ktp) {
                Storage::delete($pembaruan->img_ktp);
            }
            $validateData['img_ktp'] = $request->file('img_ktp')->store('img-pembaruan-ktp');
        }

        if ($request->file('img_paspor')) {
            if ($pembaruan->img_paspor) {
                Storage::delete($pembaruan->img_paspor);
            }
            $validateData['img_paspor'] = $request->file('img_paspor')->store('img-pembaruan-ktp');
        }

        PembaruanPaspor::where('id', $pembaruan->id)
            ->update($validateData);

        return redirect('/dashboard/pembaruan')->with('success', 'Data pembaruan berhasil di perbaharui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PembaruanPaspor  $pembaruanPaspor
     * @return \Illuminate\Http\Response
     */
    public function destroy(PembaruanPaspor $pembaruan)
    {
        if ($pembaruan->img_ktp) {
            Storage::delete($pembaruan->img_ktp);
        }
        if ($pembaruan->img_paspor) {
            Storage::delete($pembaruan->img_akte);
        }
        PembaruanPaspor::destroy($pembaruan->id);

        return redirect('/dashboard/pembaruan')->with('success', 'Pembaruan Berhasil dibatalkan!');
    }
}
