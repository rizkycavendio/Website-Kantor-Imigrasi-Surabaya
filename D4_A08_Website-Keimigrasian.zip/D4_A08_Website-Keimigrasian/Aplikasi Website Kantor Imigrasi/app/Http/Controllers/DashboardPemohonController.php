<?php

namespace App\Http\Controllers;

use App\Models\Pekerjaan;
use Illuminate\Http\Request;
use App\Models\PemohonPaspor;
use App\Models\Kewarganegaraan;
use Illuminate\Support\Facades\Storage;

class DashboardPemohonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('dashboardUser/pemohon/index', [
            'pemohons' => PemohonPaspor::where('user_id', auth()->user()->id)->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboardUser/pemohon/create', [
            'kewarganegaraans' => Kewarganegaraan::all(),
            'pekerjaans' => Pekerjaan::all()
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validateData = $request->validate([
            'nama' => 'required|max:255',
            'tempat_lahir' => 'required|max:255',
            'tggl_lahir' => 'required|date',
            'kewarganegaraan_id' => 'required',
            'img_kk' => 'required|file|max:1024',
            'img_ktp' => 'required|file|max:1024',
            'img_akte' => 'required|file|max:1024',
            'pekerjaan_id' => 'required',
            'tggl_pengajuan' => 'required|date'
        ]);
        if ($request->file('img_kk')) {
            $validateData['img_kk'] = $request->file('img_kk')->store('img-pemohon-kk');
        }

        if ($request->file('img_ktp')) {
            $validateData['img_ktp'] = $request->file('img_ktp')->store('img-pemohon-ktp');
        }

        if ($request->file('img_akte')) {
            $validateData['img_akte'] = $request->file('img_akte')->store('img-pemohon-akte');
        }

        $validateData['user_id'] = auth()->user()->id;
        PemohonPaspor::create($validateData);

        return redirect('/dashboard/pemohon')->with('success', 'Permohonan paspor Anda BERHASIL!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\PemohonPaspor  $pemohonPaspor
     * @return \Illuminate\Http\Response
     */
    public function show(PemohonPaspor $pemohon)
    {
        return view('dashboardUser/pemohon/show', [
            'pemohon' => $pemohon,
            'kewarganegaraans' => Kewarganegaraan::all(),
            'pekerjaans' => Pekerjaan::all()
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\PemohonPaspor  $pemohonPaspor
     * @return \Illuminate\Http\Response
     */
    public function edit(PemohonPaspor $pemohon)
    {
        return view('dashboardUser/pemohon/edit', [
            'pemohon' => $pemohon,
            'pekerjaans' => Pekerjaan::all(),
            'kewarganegaraans' => Kewarganegaraan::all()
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\PemohonPaspor  $pemohonPaspor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PemohonPaspor $pemohon)
    {
        $rules = [
            'nama' => 'required|max:255',
            'tempat_lahir' => 'required|max:255',
            'tggl_lahir' => 'required|date',
            'kewarganegaraan_id' => 'required',
            'img_kk' => 'required|file|max:1024',
            'img_ktp' => 'required|file|max:1024',
            'img_akte' => 'required|file|max:1024',
            'pekerjaan_id' => 'required',
            'tggl_pengajuan' => 'required|date'
        ];

        $validateData = $request->validate($rules);

        if ($request->file('img_kk')) {
            if ($pemohon->img_kk) {
                Storage::delete($pemohon->img_kk);
            }
            $validateData['img_kk'] = $request->file('img_kk')->store('img-pemohon-kk');
        }

        if ($request->file('img_ktp')) {
            if ($pemohon->img_ktp) {
                Storage::delete($pemohon->img_ktp);
            }
            $validateData['img_ktp'] = $request->file('img_ktp')->store('img-pemohon-ktp');
        }

        if ($request->file('img_akte')) {
            if ($pemohon->img_akte) {
                Storage::delete($pemohon->img_akte);
            }
            $validateData['img_akte'] = $request->file('img_akte')->store('img-pemohon-akte');
        }

        PemohonPaspor::where('id', $pemohon->id)
            ->update($validateData);

        return redirect('/dashboard/pemohon')->with('success', 'Data pemohon berhasil di perbaharui!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\PemohonPaspor  $pemohonPaspor
     * @return \Illuminate\Http\Response
     */
    public function destroy(PemohonPaspor $pemohon)
    {
        if ($pemohon->img_kk) {
            Storage::delete($pemohon->img_kk);
        }
        if ($pemohon->img_ktp) {
            Storage::delete($pemohon->img_ktp);
        }
        if ($pemohon->img_akte) {
            Storage::delete($pemohon->img_akte);
        }
        PemohonPaspor::destroy($pemohon->id);

        return redirect('/dashboard/pemohon')->with('success', 'PengajuanBerhasil dibatalkan!');
    }
}
