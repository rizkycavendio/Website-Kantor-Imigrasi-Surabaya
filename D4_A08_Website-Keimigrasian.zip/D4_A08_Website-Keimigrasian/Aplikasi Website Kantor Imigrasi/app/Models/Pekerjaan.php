<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pekerjaan extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    public function user()
    {
        return $this->belongsToMany(User::class);
    }

    public function PemohonPaspors()
    {
        return $this->hasMany(PemohonPaspor::class);
    }

    public function PembaruanPaspors()
    {
        return $this->hasMany(PembaruanPaspor::class);
    }
}
