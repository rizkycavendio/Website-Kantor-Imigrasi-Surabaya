@extends('layouts/main')

@section('container')
<section class="mt-3">
   <div class="container-lg">
          <div class="text-center mt-3">
              <h2>Sejarah</h2>
              <hr style="height:2px;border-width:0;color:rgb(0, 0, 0);background-color:#000000">
              <p class="lead text-muted">Sejarah Kantor Imigrasi Surabaya</p>
          </div>
          <div class="row mt-5 justify-content-center">
            <div class="col-lg-8">
                <h5 class="text-muted">Terhitung sejak tanggal 10 Mei 2006, Kantor Imigrasi Kelas I Khusus TPI Surabaya termasuk salah satu Kantor Imigrasi yang ditingkatkan kelasnya dari Kelas I menjadi Kelas I Khusus berdasarkan Keputusan Menteri Hukum dan HAM RI No. M.01-PR.07.04 Tahun 2006. Perubahan status ini tentunya diharapkan dapat mengantisipasi peningkatan beban kerja dalam rangka memberikan pelayanan jasa keimigrasian kepada masyarakat yang dapat dipertanggung jawabkan kepada Pemerintah dan masyarakat itu sendiri. <br> <br>

                Kantor Imigrasi Kelas I Khusus TPI Surabaya adalah Kantor Unit Pelaksanaan Teknis Keimigrasian berada di bawah Kantor Wilayah Kementerian Hukum dan  Hak Asasi Manusia Jawa Timur, dipimpin oleh seorang Kepala Kantor dengan jabatan Struktural setingkat Eselon II b. Kantor Imigrasi Kelas I Khusus TPI Surabaya terdiri dari Kantor Imigrasi di Jalan Raya Juanda KM. 3-4 Sedati, Sidoarjo dan Tempat Pemeriksaan Imigrasi ( TPI ) di Bandar Udara Juanda Surabaya. Wilayah kerja Kantor Imigrasi Kelas I Khusus TPI Surabaya  meliputi : <br> <br>

               1.  Kota Surabaya: <br> <br>
                        Surabaya Selatan; 10 (sepuluh) Kecamatan <br>
                        Surabaya Tengah; 8 (delapan) Kecamatan <br>
                        Surabaya Utara; 3 (tiga) Kecamatan <br> 
                        Luas wilayah Surabaya sekitar 350,5 km² dengan jumlah penduduk sekitar 2,765 juta jiwa. <br> <br>
                
                2. Kabupaten Sidoarjo; Terdiri dari 17 (tujuh belas) Kecamatan. Luas wilayah Kabupaten Sidoarjo sekitar 634,4 km² dengan jumlah penduduk sekitar 1,996 juta jiwa. <br> <br>

                3. Kota Mojokerto; Terdiri dari 2 (dua) Kecamatan. Luas wilayah Kota Mojokerto 16.46 km² dengan jumlah  penduduk sekitar 120.196 jiwa. <br> <br>

                4. Kabupaten Mojokerto; Meliputi 17 (tujuh belas) Kecamatan. Luas wilayah Kabupaten Mojokerto 872  km2 dengan jumlah penduduk sekitar 1,054 juta jiwa.
                
                </h5>
            </div>
          </div>
    </div>
</section>
@endsection

 
      

