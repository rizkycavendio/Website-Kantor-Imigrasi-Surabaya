@extends('layouts/main')

@section('container')
<div class="container-lg mt-5 mb-5">
  <div class="row justify-content-center">
      <div class="col-lg-4">
          <main class="form-signin w-100 m-auto">
            @if (session()->has('success'))
            {{-- jika di session terdapat loginError, maka tampilkan di bawah ini --}}
            <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{-- isi pesannya di bawhah ini, mengambil dari session loginError tadi di dalam LoginController --}}
               {{ session('success') }}   
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
             @endif
            @if (session()->has('loginError'))
            {{-- jika di session terdapat loginError, maka tampilkan di bawah ini --}}
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{-- isi pesannya di bawhah ini, mengambil dari session loginError tadi di dalam LoginController --}}
               {{ session('loginError') }}   
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
             @endif
            <form action="/login" method="POST">
              @csrf
              <div class="card p-5 border-0 shadow">
                <h1 class="h3 mb-3 fw-normal text-center">Silahkan Login</h1>
              <div class="mb-3">
                <label for="nik" class="from-label">NIK: </label>
                  <input type="text" class="form-control" id="nik" placeholder="200513...." name="nik">
                </div>
              <div class="mb-3">
                <label for="email" class="from-label">Email: </label>
                <input type="email" class="form-control" id="email" placeholder="name@gmail.com" name="email">
              </div>
              <div class="mb-3">
                <label for="password" class="from-label">Password: </label>
                <input type="password" class="form-control" id="password" placeholder="Password" name="password">
              </div>
              <button class="w-100 btn btn-lg btn-warning mt-5" type="submit">Login</button>
              <small class="d-block text-center mt-2">Belum Registrasi? <a href="/register"> Registrasi di sini</a></small>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
@endsection
