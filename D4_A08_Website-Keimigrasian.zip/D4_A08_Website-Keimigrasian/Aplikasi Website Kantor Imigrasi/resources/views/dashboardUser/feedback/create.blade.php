@extends('dashboardUser/layouts/main')

@section('container')
<div class="container-lg mt-3 mb-5">
    <h2>Tulis Ulasan Anda: </h2>
      <hr>
      <div class="row">
        <div class="col-lg-4">
            <form action="/dashboard/feedback" method="POST">
                @csrf
                <div class="card border-0 rounded shadow">
                    <div class="card-body">
                        <h5>Feedback pelayanan:</h5>
                        <hr>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <a class="text-warning"><i class="bi bi-star-fill"></i></a>
                        <div class="mb-2 mt-2">
                            <label for="ulasan" class="from-label mb-2">Isi Ulasan:</label>
                            <textarea type="submit" class="form-control @error('ulasan') is-invalid @enderror" id="ulasan" placeholder="Masukkan ulasan Anda..." name="ulasan" value="{{ old('ulasan') }}"></textarea>
                            @error('ulasan')
                            <div class="invalid-feedback">
                              {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <hr>
                        <div class="mt-3">
                            <div class="col-lg-6">
                                <button class="border-0 text-light badge bg-info text-decoration-none" >KIRIM  <span data-feather="navigation"></span></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
  </div>

@endsection