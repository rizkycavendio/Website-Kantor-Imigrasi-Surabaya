@extends('dashboardUser/layouts/main')

@section('container')
<div class="container-lg mt-3 mb-5">
  <h2>Form Pengajuan Pembuatan Paspor</h2>
    <hr>
  <div class="row">
      <div class="col-lg-8">
          <main class="form-signin w-100 m-auto">
            @if (session()->has('loginError'))
              {{-- jika di session terdapat loginError, maka tampilkan di bawah ini --}}
             <div class="alert alert-danger alert-dismissible fade show" role="alert">
              {{-- isi pesannya di bawhah ini, mengambil dari session loginError tadi di dalam LoginController --}}
                {{ session('loginError') }}   
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
             </div>
            @endif
            <form action="/dashboard/pemohon" method="POST" enctype="multipart/form-data">
              @csrf
              <div class="container">
                  <div class="mb-2">
                    <label for="nama" class="from-label">Nama:</label>
                    <input type="text" class="form-control @error('nama') is-invalid @enderror" id="nama" placeholder="Masukkan nama Anda..." name="nama" autofocus value="{{ old('nama') }}">
                    @error('nama')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-2">
                    <label for="tempat_lahir" class="from-label">Tempat Lahir: </label>
                    <input type="text" class="form-control @error('tempat_lahir') is-invalid @enderror" id="tempat_lahir" placeholder="Masukkan tempat lahir Anda..." name="tempat_lahir" value="{{ old('tempat_lahir') }}">
                    @error('tempat_lahir')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-2">
                    <label for="tggl_lahir" class="from-label">Tanggal Lahir:</label>
                    <input type="date" class="form-control @error('tggl_lahir') is-invalid @enderror" id="tggl_lahir" placeholder="Masukkan tanggal lahir Anda..." name="tggl_lahir" value="{{ old('tggl_lahir') }}">
                    @error('tggl_lahir')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                    @enderror
                  </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Pekerjaan:</label>
                    <select class="form-select" name="pekerjaan_id" >
                      @foreach ($pekerjaans as $pekerjaan)
                        @if (old('pekerjaan_id') == $pekerjaan->id)
                        <option value="{{ $pekerjaan->id }}"selected>{{ $pekerjaan->pekerjaan }}</option>  
                        @else
                        <option value="{{ $pekerjaan->id }}">{{ $pekerjaan->pekerjaan }}</option>  
                        @endif
                      @endforeach
                    </select>
                 </div>
                  <div class="mb-2">
                    <label for="slug" class="form-label">Kewarganegaraan:</label>
                    <select class="form-select" name="kewarganegaraan_id" >
                      @foreach ($kewarganegaraans as $kewarganegaraan)
                        @if (old('kewarganegaraan_id') == $kewarganegaraan->id)
                        <option value="{{ $kewarganegaraan->id }}"selected>{{ $kewarganegaraan->kewarganegaraan }}</option>  
                        @else
                        <option value="{{ $kewarganegaraan->id }}">{{ $kewarganegaraan->kewarganegaraan }}</option>  
                        @endif
                      @endforeach
                    </select>
                 </div>
                 <div class="mb-3">
                  <label for="img_kk" class="form-label">Upload Kartu Keluarga (KK)</label>
                  <img class="img-preview1 img-fluid mb-3 col-sm-5">
                  <input class="form-control  @error('img_kk') is-invalid @enderror" type="file" id="img_kk" name="img_kk" onchange="previewImg_kk()">
                    @error('img_kk')
                        <div class="invalid-feedback">
                          {{ $message }}
                        </div>
                    @enderror
                 </div>
                 <div class="mb-3">
                  <label for="img_ktp" class="form-label">Upload Kartu Identitas (KTP/Kartu Pelajar/SIM)</label>
                  <img class="img-preview2 img-fluid mb-3 col-sm-5">
                  <input class="form-control  @error('img_ktp') is-invalid @enderror" type="file" id="img_ktp" name="img_ktp" onchange="previewImg_ktp()">
                    @error('img_ktp')
                        <div class="invalid-feedback">
                          {{ $message }}
                        </div>
                    @enderror
                 </div>
                 <div class="mb-3">
                  <label for="img_akte" class="form-label">Upload Akte Kelahiran</label>
                  <img class="img-preview3 img-fluid mb-3 col-sm-5">
                  <input class="form-control  @error('img_akte') is-invalid @enderror" type="file" id="img_akte" name="img_akte" onchange="previewImg_akte()">
                    @error('img_akte')
                        <div class="invalid-feedback">
                          {{ $message }}
                        </div>
                    @enderror
                 </div>
                  <div class="mb-2">
                  <label for="tggl_pengajuan" class="from-label">Tanggal Pengajuan Paspor:</label>
                  <input type="date" class="form-control @error('tggl_pengajuan') is-invalid @enderror" id="tggl_pengajuan" placeholder="name@example.com" name="tggl_pengajuan" value="{{ old('tggl_pengajuan') }}">
                  @error('tggl_pengajuan')
                    <div class="invalid-feedback">
                      {{ $message }}
                    </div>
                  @enderror
                  </div>
                  <button class="btn btn-lg btn-warning mt-3" type="submit">Ajukan Paspor</button>
              </div>
            </form>
          </main>
      </div>
  </div>
</div>
@endsection


