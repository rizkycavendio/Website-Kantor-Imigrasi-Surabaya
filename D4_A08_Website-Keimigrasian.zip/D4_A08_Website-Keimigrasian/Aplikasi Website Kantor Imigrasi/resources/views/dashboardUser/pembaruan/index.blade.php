@extends('dashboardUser/layouts/main')

@section('container')
<div class="container mt-4">
  <h2>Pembaruan Paspor Anda:</h2>
  <hr>
  <div class="col-lg-8">
    @if (session()->has('success'))
    <div class="alert alert-success" role="alert">
      {{ session('success') }}
    </div>
  </div>
  @endif
  <div class="col-lg-8">
    @foreach ($pembaruans as $pembaruan)
    <div class="card shadow border-0 p-4 mt-5">
      <h5>Data Pembaruan Paspor</h5>
      <hr>
        <h6>No Antrian: <a class="text-muted text-decoration-none">{{ $pembaruan->id }} </a></h6>
        <h6>Nama: <a class="text-muted text-decoration-none">{{ $pembaruan->nama }} </a></h6> 
        <h6>Pekerjaan: <a class="text-muted text-decoration-none">{{ $pembaruan->pekerjaan->pekerjaan }} </a></h6>
        <h6>Kewarganegaraan: <a class="text-muted text-decoration-none">{{ $pembaruan->kewarganegaraan->kewarganegaraan }} </a></h6>
        <h6>Tanggal Pembaruan: <a class="text-muted text-decoration-none">{{ $pembaruan->tggl_pembaruan }} </a></h6>
        <br>
        <h5>Action:</h5>
        <div class="col-lg-8">
          <a href="/dashboard/pembaruan/{{ $pembaruan->id }}/edit" class="text-light badge bg-success text-decoration-none" >Perbaharui Data  <span data-feather="edit"></span></a>
          <a href="/dashboard/pembaruan/{{ $pembaruan->id }}" class="text-light badge bg-info text-decoration-none" >Lihat Data  <span data-feather="eye"></span></a>
          <form action="/dashboard/pembaruan/{{ $pembaruan->id }}" method="POST" class="d-inline">
            @method('delete')
            @csrf
            <button class="badge bg-danger border-0" onclick="return confirm('Serius ingin dibatalkan?')">Batalkan  <span data-feather="x-circle"></span></button>
           </form>
        </div>
    </div>
    @endforeach
</div>
</div>
@endsection